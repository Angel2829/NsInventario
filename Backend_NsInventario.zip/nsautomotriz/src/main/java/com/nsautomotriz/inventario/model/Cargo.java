package com.nsautomotriz.inventario.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "cargos")
public class Cargo {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long idCargo;
	private String nombreCargo;
	
	
//Metodo Constructor 
	public Cargo() {
			}
	
	public Cargo(String nombreCargo) {
		super();
		this.nombreCargo = nombreCargo;
	}

	//getters and setters 
	public Long getId() {
		return idCargo;
	}


	public void setId(Long id) {
		this.idCargo = id;
	}


	public String getNombreCargo() {
		return nombreCargo;
	}


	public void setNombreCargo(String nombreCargo) {
		this.nombreCargo = nombreCargo;
	}


}
