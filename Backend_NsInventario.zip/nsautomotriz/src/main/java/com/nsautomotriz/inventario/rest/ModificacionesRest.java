package com.nsautomotriz.inventario.rest;

import java.util.List;
import java.net.URI;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.nsautomotriz.inventario.model.Modificaciones;
import com.nsautomotriz.inventario.services.ModificacionesSerivices;


@RestController 
@RequestMapping("/modificacion/")
public class ModificacionesRest {
	
	@Autowired
	private ModificacionesSerivices modificacionesSerivices;
	
	@GetMapping
	private ResponseEntity<List <Modificaciones>> getAllModificaciones(){
		return ResponseEntity.ok(modificacionesSerivices.findAll());
	}
	
	@PostMapping
	private ResponseEntity<Modificaciones> saveModificacion (@RequestBody Modificaciones modificaciones){
		try {
			Modificaciones modificacionsave = modificacionesSerivices.save(modificaciones);
			return ResponseEntity.created(new URI("/modificacion/"+modificacionsave.getId())).body(modificacionsave);
					} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
		}
	}
	

}
