package com.nsautomotriz.inventario.model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "logUsuariosProductos")
public class Modificaciones {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;
	private String descripcion;
	private String usuarioModifica;
	private String fechaModifica;
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="idProducto")
	private Producto idProducto;

	//Metodo Constructor 
		public Modificaciones( String descripcion,String usuarioModifica,String fechaModifica, Producto idProducto) {
		super();
		this.descripcion = descripcion;
		this.idProducto = idProducto;
		this.usuarioModifica=usuarioModifica;
		this.fechaModifica=fechaModifica;
	}	
		public Modificaciones() {
			
		}
	//getters and setters 
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	
	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	public String getUsuarioModifica() {
		return usuarioModifica;
	}
	public void setUsuarioModifica(String usuarioModifica) {
		this.usuarioModifica = usuarioModifica;
	}
	public String getFechaModifica() {
		return fechaModifica;
	}
	public void setFechaModifica(String fechaModifica) {
		this.fechaModifica = fechaModifica;
	}
	public Producto getIdProducto() {
		return idProducto;
	}
	public void setIdProducto(Producto idProducto) {
		this.idProducto = idProducto;
	}


	
}
