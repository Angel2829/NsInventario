package com.nsautomotriz.inventario.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.nsautomotriz.inventario.model.Usuario;
import com.nsautomotriz.inventario.repository.UsuarioRepository;

@Service
public class UsuarioServices implements UsuarioRepository{

	@Autowired
	private UsuarioRepository usuarioRepository;

	@Override
	public List<com.nsautomotriz.inventario.model.Usuario> findAll() {
		return usuarioRepository.findAll();
	}
	
	public List<Usuario> findAllByIdUsuario (Long id){
		List<Usuario> estadosRespuesta= new ArrayList<>();
		List<Usuario> usuarios= usuarioRepository.findAll();
		for (int i=0; i<usuarios.size(); i++) {
			if (usuarios.get(i).getIdUsuario()==id) {
				estadosRespuesta.add(usuarios.get(i));
			}
		}
		return estadosRespuesta;
	}

	@Override
	public List<com.nsautomotriz.inventario.model.Usuario> findAll(Sort sort) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<com.nsautomotriz.inventario.model.Usuario> findAllById(Iterable<Long> ids) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <S extends com.nsautomotriz.inventario.model.Usuario> List<S> saveAll(Iterable<S> entities) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void flush() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public <S extends com.nsautomotriz.inventario.model.Usuario> S saveAndFlush(S entity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <S extends com.nsautomotriz.inventario.model.Usuario> List<S> saveAllAndFlush(Iterable<S> entities) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteAllInBatch(Iterable<com.nsautomotriz.inventario.model.Usuario> entities) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteAllByIdInBatch(Iterable<Long> ids) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteAllInBatch() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public com.nsautomotriz.inventario.model.Usuario getOne(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public com.nsautomotriz.inventario.model.Usuario getById(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <S extends com.nsautomotriz.inventario.model.Usuario> List<S> findAll(Example<S> example) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <S extends com.nsautomotriz.inventario.model.Usuario> List<S> findAll(Example<S> example, Sort sort) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Page<com.nsautomotriz.inventario.model.Usuario> findAll(Pageable pageable) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <S extends com.nsautomotriz.inventario.model.Usuario> S save(S entity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Optional<com.nsautomotriz.inventario.model.Usuario> findById(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean existsById(Long id) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public long count() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void deleteById(Long id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(com.nsautomotriz.inventario.model.Usuario entity) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteAllById(Iterable<? extends Long> ids) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteAll(Iterable<? extends com.nsautomotriz.inventario.model.Usuario> entities) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteAll() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public <S extends com.nsautomotriz.inventario.model.Usuario> Optional<S> findOne(Example<S> example) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <S extends com.nsautomotriz.inventario.model.Usuario> Page<S> findAll(Example<S> example,
			Pageable pageable) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <S extends com.nsautomotriz.inventario.model.Usuario> long count(Example<S> example) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public <S extends com.nsautomotriz.inventario.model.Usuario> boolean exists(Example<S> example) {
		// TODO Auto-generated method stub
		return false;
	}


}
