package com.nsautomotriz.inventario.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "usuarios")
public class Usuario {
	
		@Id
		@GeneratedValue(strategy = GenerationType.AUTO)
		private Long idUsuario;
		private String nombre;
		private String edad;
		private String fechaIngreso;
		@ManyToOne
		@JoinColumn(name="idCargo")
		private Cargo idCargo;
		
		//Metodo Constructor 
		public  Usuario() {
			
		}
		
		public Usuario(String nombre, String edad, String fechaIngreso, Cargo idCargo) {
			super();
			this.nombre = nombre;
			this.edad = edad;
			this.fechaIngreso = fechaIngreso;
			this.idCargo = idCargo;
		}
		
		//getters and setters 
		public Long getIdUsuario() {
			return idUsuario;
		}
		public void setIdUsuario(Long idUsuario) {
			this.idUsuario = idUsuario;
		}
		public String getNombre() {
			return nombre;
		}
		public void setNombre(String nombre) {
			this.nombre = nombre;
		}
		public String getEdad() {
			return edad;
		}
		public void setEdad(String edad) {
			this.edad = edad;
		}
		public String getFechaIngreso() {
			return fechaIngreso;
		}
		public void setFechaIngreso(String fechaIngreso) {
			this.fechaIngreso = fechaIngreso;
		}
		public Cargo getIdCargo() {
			return idCargo;
		}
		public void setIdCargo(Cargo idCargo) {
			this.idCargo = idCargo;
		}
		
		


		
}
