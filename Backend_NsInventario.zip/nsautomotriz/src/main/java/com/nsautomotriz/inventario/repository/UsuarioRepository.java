package com.nsautomotriz.inventario.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nsautomotriz.inventario.model.Usuario;

public interface UsuarioRepository extends JpaRepository<Usuario, Long>{

}
