package com.nsautomotriz.inventario.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.nsautomotriz.inventario.model.Usuario;
import com.nsautomotriz.inventario.services.UsuarioServices;

@RestController
@RequestMapping("/usuario/")
public class UsuarioRest {

	@Autowired 
	private UsuarioServices usuarioServices;
	
	@GetMapping
	private ResponseEntity<List<Usuario>> getAllUsuarios(){
		return ResponseEntity.ok(usuarioServices.findAll());
	}
	
	@GetMapping ("{idUsuario}")
	private ResponseEntity<List<Usuario>> getAllUsuariosById (@PathVariable("idUsuario") Long idusuario){
		return ResponseEntity.ok(usuarioServices.findAllByIdUsuario(idusuario));
		
	}

	
}
