package com.nsautomotriz.inventario.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.nsautomotriz.inventario.model.Modificaciones;

public interface ModificacionesRepository extends JpaRepository<Modificaciones, Long> {

}
