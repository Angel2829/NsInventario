package com.nsautomotriz.inventario.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.nsautomotriz.inventario.model.Cargo;

public interface CargoRepository extends JpaRepository<Cargo, Long> {

}
