import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CargosService } from './services/cargos/cargos.service';
import { ModificacionesService } from './services/modificaciones/modificaciones.service';
import { ProductosService } from './services/productos/productos.service';
import { UsuariosService } from './services/usuarios/usuarios.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers: [DatePipe]

})


export class AppComponent implements OnInit {

  cargos: any;
  modificaciones: any;
  productoForm : FormGroup;
  productoForm2 : FormGroup;
  usuarios: any;
  productos:any;
  validaUsuario:any;
  msg : String;
  fechaActual:any;
  hideUpdate:boolean= true;
  nombreProducto:any;
  modificacionesData:any
  Idproductoparainsercion:any

  constructor (
    public fb: FormBuilder,
    public cargosService: CargosService,
    public modificacionesService: ModificacionesService,
    public productosService: ProductosService,
    public usuariosService: UsuariosService,
           
  ){

  }
  ngOnInit(): void {
    
    this.productoForm = this.fb.group({
    idProducto:[''],
    nombre : ['',Validators.required],
		cantidad : ['',Validators.required],
		fechaIngreso : ['',Validators.required],
		idUsuario : ['',Validators.required],
     
  });

  this.productoForm2 = this.fb.group({
    idProducto:[''],
    nombre : ['',Validators.required],
		cantidad : ['',Validators.required],
		fechaIngreso : ['',Validators.required],
		idUsuario : ['',Validators.required],
     
  });
    
    this.usuariosService.getAllUsuarios().subscribe(resp=>{
      this.usuarios = resp;
      console.log("Esta es la respuesta para lista de Usuarios=>", resp)
        },
    error=>{console.error(error)}
    );
   
    this.productosService.getAllProductos().subscribe(resp=>{
      this.productos = resp;
      console.log("Estos son los productos",this.nombreProducto)
      console.log("Esta es la respuesta para lista de Productos=>", resp) 
         },
    error=>{console.error(error)}
    );

    
    this.productoForm.value.idUsuario = parseInt(this.productoForm.value.idUsuario);
    this.productoForm

    this.productoForm2.value.idUsuario = parseInt(this.productoForm2.value.idUsuario);
    this.productoForm2

    // this.productoForm2.value.idProducto = parseInt(this.productoForm2.value.idProducto);
    // this.productoForm2

    let date = new Date();
    let day = date.getDate();
    let month = date.getMonth() + 1;
    let year = date.getFullYear();
    if(month < 10){
      this.fechaActual= `${year}-0${month}-${day}`;
    }else{
      this.fechaActual= `${year}-${month}-${day}`;
    }

 
  }

  guardar():void{
    if (this.productoForm.value.fechaIngreso<=this.fechaActual){
        this.productosService.SaveProducto(this.productoForm.value).subscribe(resp=>{
        this.msg='Producto agregado con exito!';
        this.productoForm.reset(); 
        
        this.productos.push(resp)
      },
      error=>{console.error(error)}
      ) 
    }else {
             alert('Error de fecha: la fecha de registro no puede ser mayor a hoy');
      
    }
     
 
  }

  actualizar():void{

    if (this.productoForm2.value.fechaIngreso<=this.fechaActual){

    this.productosService.SaveProducto(this.productoForm2.value).subscribe(resp=>{
    this.Idproductoparainsercion={
    idProducto:parseInt(this.productoForm2.value.idProducto),

      }
      this.modificacionesData={
      id :'',
      descripcion:'Modificacion', 
      idProducto:this.Idproductoparainsercion,
      usuarioModifica:this.productoForm2.value.idUsuario.nombre,
      fechaModifica:this.fechaActual
    }
    this.modificacionesService.SaveModificaciones(this.modificacionesData).subscribe(respu=>{
      this.modificaciones.push(respu);
    },
    error=>{console.error("Error al isertar el log de update",error)}
    )  
    this.msg='Producto actualizado con exito!';
    this.productoForm2.reset(); 
    this.productos=this.productos.filter((producto: { idProducto: any; })=> resp.idProducto!==producto.idProducto);
    this.productos.push(resp);
    this.hideUpdate=true 
  },
    error=>{console.error(error)}
    )
  }else {
    alert('Error de fecha: la fecha de registro no puede ser mayor a hoy');
}
  }
 
  eliminar (producto:any){
    var answer = confirm('Estas seguro querer eliminarlo?')
    if(answer){
      this.productosService.deleteProducto(producto.idProducto).subscribe(resp=>{
        if(resp==true){
          this.msg='Producto eliminado con exito!';
          this.productos.pop(producto)
        }
  
      }
      )
    }
   
  }

  editar (producto:any){
    this.hideUpdate=false,
    this.productoForm2.setValue({
    idProducto: producto.idProducto,
    nombre : producto.nombre ,
		cantidad : producto.cantidad ,
		fechaIngreso : producto.fechaIngreso ,
		idUsuario : producto.idUsuario ,
        })
  }

  closeAlert() :void {this.msg ='';}
  
}
