import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProductosService {

  private API_SERVER ="http://localhost:8080/producto/";

  constructor(
  private httpClient: HttpClient
  ) { }

  public getAllUsuarios(): Observable <any>{
    return this.httpClient.get(this.API_SERVER)
  }

  public SaveProducto(producto:any): Observable <any>{
    return this.httpClient.post(this.API_SERVER,producto);
  }

  public getAllProductos(): Observable <any>{
    return this.httpClient.get(this.API_SERVER)
  }

  public deleteProducto(idProducto:any):Observable<any>{
    return this.httpClient.delete(this.API_SERVER+"delete/"+idProducto);
  } 

}
