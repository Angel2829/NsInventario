import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ModificacionesService {
  private API_SERVER ="http://localhost:8080/modificacion/";


  constructor(
    private httpClient: HttpClient
    ) { }

    
    public getAllModificaciones(): Observable <any>{
      return this.httpClient.get(this.API_SERVER)
    }

    public SaveModificaciones(modificacion:any): Observable <any>{
      return this.httpClient.post(this.API_SERVER,modificacion)
    }
}
