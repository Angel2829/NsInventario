import { TestBed } from '@angular/core/testing';

import { ModificacionesService } from './modificaciones.service';

describe('ModificacionesService', () => {
  let service: ModificacionesService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ModificacionesService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
